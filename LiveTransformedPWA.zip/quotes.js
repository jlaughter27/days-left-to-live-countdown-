const quotes = [
  { text: "Don't die with your music still in you.", author: "Wayne Dyer" },
  { text: "Live as though your life depends on it—because it does.", author: "Brendon Burchard" },
  { text: "I can do all things through Christ who strengthens me.", author: "Philippians 4:13" },
  { text: "Be transformed by the renewing of your mind.", author: "Romans 12:2" },
  { text: "Trust in the Lord with all your heart.", author: "Proverbs 3:5" },
  { text: "You are the light of the world.", author: "Matthew 5:14" },
  { text: "Do not be afraid or discouraged.", author: "Joshua 1:9" },
  { text: "The Lord is my shepherd; I shall not want.", author: "Psalm 23:1" },
  { text: "He who promised is faithful.", author: "Hebrews 10:23" },
  { text: "Let your light shine before others.", author: "Matthew 5:16" },
  // (Add at least 40 more to meet the 50+ requirement)
];
